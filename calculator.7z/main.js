var App = angular.module('App', [
	'calculator'
]);
App.controller('MainCtrl', ['$scope', function($scope){
	
}])

angular.module('calculator', [])
.factory('Utils', [function(){
	return {
		getLastChar: function(string){
			return string.slice(-1);
		}
	}
}])
.directive('calculator', function(Utils){
	return {
		restrict: 'AE',
		scope: {
			mode: '@'
		},
		templateUrl: 'calculator.tpl.html',
		link: function(scope){

			scope.data = {
				result: '',
				small: '',
				operators: ['/', '*', '-', '+']
			};

			var isAfterOperator = false;
			var addNumber = function(number){
				var str = number.toString();
				if (str === '.' && (scope.data.result.length === 0 || str === Utils.getLastChar(scope.data.result))) {
					return false;
				}
				if (isAfterOperator === true) {
					scope.data.result = str;
				}
				else{
					scope.data.result += str;
				}
				isAfterOperator = false;
			};
			var triggerOperation = function(opt){
				if (scope.data.result.length === 0 || scope.data.operators.indexOf(Utils.getLastChar(scope.data.result)) > -1) {
					return false;
				}
				scope.data.small += (scope.data.result + opt);
				isAfterOperator = true;
			};
			var doTheMath = function(){
				if (scope.data.operators.indexOf(Utils.getLastChar(scope.data.result)) > -1) {
					scope.data.result = scope.data.result.slice(0, -1);
				}
				scope.data.result = eval(scope.data.small + scope.data.result).toString();
				scope.data.small = '';
			};

			angular.extend(scope, {
				addNumber: addNumber,
				triggerOperation: triggerOperation,
				doTheMath: doTheMath
			});
		}
	}
});